package streams.lambas;

import java.util.Scanner;

public class InputValidater {
    private static final Scanner sc = new Scanner(System.in);

    // Integer input with range validation
    public static int getInt(String prompt, int min, int max) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = Integer.parseInt(sc.nextLine().trim());
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Error: Enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number. Try again.");
            }
        }
    }

    // String input (non-empty)
    public static String getString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("Error: Input cannot be empty. Try again.");
        }
    }
}
