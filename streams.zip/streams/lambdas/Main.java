package streams.lambas;

public class Main {
    public static void main(String[] args) {
        System.out.println("Program started...");
        
        boolean running = true;
        while (running) {
            System.out.println("\n--- Horse Racing Game ---");
            System.out.println("1. Start a race");
            System.out.println("2. Exit game");
            
            int choice = InputValidater.getInt("Choose an option: ", 1, 2);

            if (choice == 1) {
                // Ask race details
                int numHorses = InputValidater.getInt("\nEnter number of horses: ", 1, 100);
                int distance = InputValidater.getInt("Enter track distance: ", 10, 1000);

                Race race = new Race(distance);

                // Add horses
                for (int i = 0; i < numHorses; i++) {
                    System.out.println("\nHorse #" + (i + 1));
                    String name = InputValidater.getString("Enter horse name: ");
                    String warcry = InputValidater.getString("Enter horse warcry: ");
                    int age = InputValidater.getInt("Enter horse age: ", 1, 30);

                    Horse horse = new Horse(name, warcry, age, Math.random() < 0.5);
                    race.addHorse(horse);
                }

                // Check qualified horses
                if (race.getHorses().isEmpty()) {
                    System.out.println("\n0 Qualified Horses. Thus, no race.");
                } else {
                    race.categorizeHorses();
                    race.startRace();
                }
            } else if (choice == 2) {
                running = false;
                System.out.println("Exiting game... Goodbye!");
            }
        }
    }
}
