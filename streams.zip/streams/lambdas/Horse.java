package streams.lambas;

import java.util.Random;

public class Horse {
    private final String name;
    private final String warcry;
    private final int age;
    private final boolean healthy;
    private Category category;
    private int distanceCovered;

    public Horse(String name, String warcry, int age, boolean healthy) {
        this.name = name;
        this.warcry = warcry;
        this.age = age;
        this.healthy = healthy;
    }

    // Generate speed based on category rules
    public int generateSpeed(int genCount, Random rand) {
        int speed = rand.nextInt(10) + 1;
        if (category == Category.ADVANCED && genCount >= 3) {
            speed = 5 + rand.nextInt(6); // random between 5–10
        } else if (category == Category.INTERMEDIATE && genCount >= 5) {
            speed = (int) Math.round(speed * 1.1); // add 10%
        }
        return speed;
    }

    // each Horse runs the race independently
    public void runRace(int distance, Random rand, Race race, int[] rank) {
        int sum = 0;
        int genCount = 0;

        while (sum < distance) {
            genCount++;
            int speed = generateSpeed(genCount, rand);
            sum += speed;   //update distance
            distanceCovered = sum;

            RacePrinter.printHorseProgress(this, speed, distance - sum);

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        synchronized (race.getResults()) { //to make sure only 1 thread updates results at a time. so one horse  thread enters this block
            race.addResult(new RaceResult(this, rank[0]++)); //give the horse a rank then increment shared rank array
            RacePrinter.printHorseFinish(this);
        }
    }

    // Getters & setters
    public String getName() { return name; }
    public String getWarcry() { return warcry; }
    public int getAge() { return age; }
    public boolean isHealthy() { return healthy; }
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    public int getDistanceCovered() { return distanceCovered; }

    @Override
    public String toString() {
        return name + " (" + category + ", age " + age + ")";
    }
}
