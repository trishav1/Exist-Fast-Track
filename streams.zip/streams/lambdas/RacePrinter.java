package streams.lambas;

import java.util.List;

public class RacePrinter {
    public static void printCountdown() {
        System.out.println("Race starting in 3...");
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {} //pause 1 second 
        System.out.println("2...");
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        System.out.println("1...");
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        System.out.println("GO!!!");
    }

    public static void printHorseProgress(Horse h, int speed, int remaining) {
        System.out.println(h.getName() + " ran " + speed + ", remaining " + Math.max(0, remaining));
    }

    public static void printHorseFinish(Horse h) {
        System.out.println(h.getName() + " finished the race! Warcry: " + h.getWarcry());
    }

    public static void printUnhealthyHorse(Horse h) {
        System.out.println(h.getName() + " is unhealthy and cannot join the race.");
    }

    public static void printQualifiedHorses(List<Horse> horses) {
        System.out.println("\n" + horses.size() + " Qualified Horses: ");
        horses.forEach(h -> System.out.println(h.getName()));
        System.out.println("\n");
    }

    public static void printResults(List<RaceResult> results) {
        System.out.println("\nFinal Results");
        results.stream()
               .sorted()
               .forEach(System.out::println);
    }
}
