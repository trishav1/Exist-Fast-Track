package streams.lambas;

import java.util.*;
import java.util.stream.*;


public class Race {
    private final List<Horse> horses = new ArrayList<>();
    private final List<RaceResult> results = new ArrayList<>();
    private final Random rand = new Random();
    private final int distance;

    public Race(int distance) {
        this.distance = distance;
    }

    public void addHorse(Horse h) { //add if healthy only. receive horse object
        if (h.isHealthy()) {
            horses.add(h);
        } else {
            RacePrinter.printUnhealthyHorse(h);
        }
    }

    public List<Horse> getHorses() {
        return horses;
    }    

    // Categorize horses
    public void categorizeHorses() {
        if (horses.isEmpty()) return;

        double avgAge = horses.stream()
                              .mapToInt(h -> h.getAge()) // convert age to a stream
                              .average() //Stream API. Can return OptionalDouble which is an alt of null or error, it can be empty.
                              .orElse(0); //if list/OptionalDouble is empty, return 0

        System.out.println("avgAge of " + horses + " is : " + avgAge);

        Map<Integer, Long> ageFreq = horses.stream() // key - integer (Age) , value - long (how many horses of that age)
                                           .collect(Collectors.groupingBy(Horse::getAge, Collectors.counting())); //instead of storing the elements, store the count of elements


        int mostCommonAge = ageFreq.entrySet().stream()
                                   .max(Map.Entry.comparingByValue())
                                   .map(Map.Entry::getKey)
                                   .orElse(-1);

        for (Horse h : horses) {
            if (h.getAge() == mostCommonAge) {
                h.setCategory(Category.ADVANCED);
            } else if (h.getAge() > avgAge) {
                h.setCategory(Category.INTERMEDIATE);
            } else {
                h.setCategory(Category.BEGINNER);
            }
        }
        System.out.println("avgAge of " + horses + " is : " + avgAge);
    }

    // Run the race
    public void startRace() {
        RacePrinter.printQualifiedHorses(horses);
        RacePrinter.printCountdown();

        //each horse has its own thread to run parallel
        List<Thread> threads = new ArrayList<>();
        final int[] rank = {1}; //shared among threads, so array

        for (Horse h : horses) { //create thread for each horse
            Thread t = new Thread(() -> h.runRace(distance, rand, this, rank));
            threads.add(t);
            t.start();//schedule for a sep thread
        }

        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        RacePrinter.printResults(results);
    }

    // Results
    public void addResult(RaceResult result) {
        results.add(result);
    }

    public List<RaceResult> getResults() {
        return results;
    }

    Object getHorses() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
