package streams.lambas;

public enum Category {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
