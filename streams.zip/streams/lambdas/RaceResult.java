package streams.lambas;

public class RaceResult implements Comparable<RaceResult> {
    private final Horse horse;
    private final int rank;

    public RaceResult(Horse horse, int rank) {
        this.horse = horse;
        this.rank = rank;
    }

    public Horse getHorse() { return horse; }
    public int getRank() { return rank; }

    @Override
    public int compareTo(RaceResult other) {
        return Integer.compare(this.rank, other.rank);
    }

    @Override
    public String toString() {
        return rank + " - " + horse.getName();
    }
}
